﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Podaj liczbę: ");
        int a = int.Parse(Console.ReadLine());
        int suma = 0;
        for (int i = 1; i <= a; i++)
        {
            suma += i;
        }
        Console.WriteLine($"Suma liczb od 1 do {a} wynosi: {suma}");
    }
}